package com.mutatio.misc;

import edu.princeton.cs.introcs.StdOut;

public class HelloWorld {
    public static void main(String[] args) {
        StdOut.println("hello world!");
    }
}
