package com.mutatio.misc;

import edu.princeton.cs.introcs.StdOut;

public class HelloGoodbye {
    public static void main(String[] args) {
        StdOut.println("good bye!");
    }
}
